#!/bin/bash

# Activate virtual environment and start the application
source venv/bin/activate
python main.py 